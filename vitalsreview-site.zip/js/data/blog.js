export const blogPosts = [
  {
    slug: "como-avaliar-suplementos",
    title: "Como avaliar um suplemento antes de comprar",
    metaDescription: "Um roteiro simples para checar composição, dosagem, selo regulatório e reputação do fabricante antes de comprar qualquer suplemento.",
    image: "https://images.unsplash.com/photo-1584362917165-526a968579e8?w=800&q=80",
    content: `
      <p>Antes de comprar qualquer suplemento, vale a pena checar alguns pontos básicos: composição completa no rótulo, dosagem de cada ingrediente, registro na Anvisa (para produtos vendidos no Brasil) e reputação do fabricante.</p>
      <p>Desconfie de promessas de resultado garantido ou muito rápido. Suplementos apoiam hábitos saudáveis, mas não substituem alimentação equilibrada, sono adequado e atividade física.</p>
      <p>Se você tem alguma condição de saúde ou usa outros medicamentos, converse com um médico ou nutricionista antes de iniciar qualquer suplemento novo.</p>
    `
  },
  {
    slug: "probioticos-o-que-diz-a-ciencia",
    title: "Probióticos: o que a ciência já sabe (e o que ainda não sabe)",
    metaDescription: "Um panorama honesto sobre o que os estudos mostram sobre probióticos e saúde intestinal, e onde as evidências ainda são limitadas.",
    image: "https://images.unsplash.com/photo-1550572017-edd951b55104?w=800&q=80",
    content: `
      <p>Existe evidência razoável de que certas cepas probióticas podem ajudar em quadros específicos, como diarreia associada a antibióticos. Já os benefícios para controle de peso ou imunidade geral têm evidências mais preliminares.</p>
      <p>Isso não significa que probióticos não funcionem — significa que os resultados variam por cepa, dose e pessoa, e que é importante ter expectativas realistas.</p>
      <p>Ao escolher um produto, prefira marcas que informem claramente as cepas (não só o gênero da bactéria) e a contagem de UFCs no momento do consumo, não só na fabricação.</p>
    `
  },
  {
    slug: "cafeina-e-metabolismo",
    title: "Cafeína e metabolismo: o que realmente muda no seu corpo",
    metaDescription: "Entenda de forma simples o papel da cafeína no metabolismo e por que ela sozinha não é uma solução para perda de peso.",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80",
    content: `
      <p>A cafeína pode gerar um pequeno aumento temporário na taxa metabólica e na queima de gordura durante exercícios, mas o efeito é modesto e diminui com o uso contínuo, à medida que o corpo desenvolve tolerância.</p>
      <p>Produtos que combinam cafeína com outros compostos costumam vender essa combinação como fórmula exclusiva, mas vale sempre checar a dose real de cada ingrediente no rótulo.</p>
      <p>Pessoas sensíveis a estimulantes, gestantes ou com problemas cardíacos devem ter cautela extra e consultar um profissional de saúde.</p>
    `
  }
];
