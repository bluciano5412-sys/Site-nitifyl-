// Links de afiliado são placeholders ("#"). Troque pelos seus hoplinks reais da ClickBank
// no formato: https://SEUID.NOMEPRODUTO.hop.clickbank.net

export const reviewsData = {
  puravive: {
    slug: "puravive",
    nome: "Puravive",
    nota: 4.2,
    imagem: "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=800&q=80",
    descricao: "Suplemento em cápsulas com uma combinação de extratos vegetais e nutrientes associados ao metabolismo, comercializado como apoio ao controle de peso.",
    resumo: "Fórmula à base de plantas voltada para quem já mantém dieta e rotina de exercícios e busca um suporte adicional.",
    pros: [
      "Fórmula sem estimulantes fortes",
      "Cápsulas fáceis de tomar, uma vez ao dia",
      "Garantia de reembolso oferecida pelo fabricante"
    ],
    cons: [
      "Preço acima da média de suplementos similares",
      "Resultados variam bastante de pessoa para pessoa",
      "Não substitui alimentação equilibrada e atividade física"
    ],
    affiliate: "#"
  },
  javaburn: {
    slug: "java-burn",
    nome: "Java Burn",
    nota: 4.0,
    imagem: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=800&q=80",
    descricao: "Pó solúvel para adicionar ao café, formulado com nutrientes e compostos vegetais associados a energia e metabolismo.",
    resumo: "Pensado para quem já tem o hábito de tomar café e quer incorporar um suplemento à rotina existente.",
    pros: [
      "Sem sabor perceptível ao misturar no café",
      "Praticidade para quem já consome café diariamente",
      "Embalagem individual facilita o uso fora de casa"
    ],
    cons: [
      "Depende do consumo regular de café para o uso pretendido",
      "Custo mensal considerável em uso contínuo",
      "Poucos estudos clínicos independentes sobre a fórmula completa"
    ],
    affiliate: "#"
  },
  leanbiome: {
    slug: "leanbiome",
    nome: "LeanBiome",
    nota: 4.3,
    imagem: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=800&q=80",
    descricao: "Suplemento probiótico com cepas de bactérias associadas à saúde intestinal, comercializado como apoio ao equilíbrio da microbiota.",
    resumo: "Direcionado a quem busca cuidar da saúde digestiva como parte de uma estratégia mais ampla de bem-estar.",
    pros: [
      "Contém cepas probióticas conhecidas na literatura científica",
      "Cápsulas com revestimento para resistir ao ácido estomacal",
      "Sem necessidade de refrigeração"
    ],
    cons: [
      "Efeitos sobre peso corporal ainda carecem de estudos robustos",
      "Pode causar desconforto digestivo nas primeiras semanas em algumas pessoas",
      "Necessário uso contínuo por vários meses para avaliar resultado"
    ],
    affiliate: "#"
  }
};
