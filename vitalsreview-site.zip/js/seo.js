export const SEOManager = {
  updateTags(title, description, canonicalUrl, ogImage) {
    const fullTitle = `${title} | VitalsReview`;
    document.title = fullTitle;
    document.querySelector('meta[name="description"]')?.setAttribute('content', description || '');
    document.querySelector('link[rel="canonical"]')?.setAttribute('href', canonicalUrl || window.location.href);
    document.querySelector('meta[property="og:title"]')?.setAttribute('content', fullTitle);
    document.querySelector('meta[property="og:description"]')?.setAttribute('content', description || '');
    document.querySelector('meta[property="og:url"]')?.setAttribute('content', window.location.href);
    document.querySelector('meta[name="twitter:title"]')?.setAttribute('content', fullTitle);
    document.querySelector('meta[name="twitter:description"]')?.setAttribute('content', description || '');
    document.querySelector('meta[name="twitter:url"]')?.setAttribute('content', window.location.href);
    if (ogImage) {
      document.querySelector('meta[property="og:image"]')?.setAttribute('content', ogImage);
      document.querySelector('meta[name="twitter:image"]')?.setAttribute('content', ogImage);
    }
  },
  injectSchema(schemaObj) {
    const scriptTag = document.getElementById('seo-schema');
    if (scriptTag) scriptTag.textContent = JSON.stringify(schemaObj, null, 2);
  },
  clearSchema() {
    const scriptTag = document.getElementById('seo-schema');
    if (scriptTag) scriptTag.textContent = '';
  },
  generateOrganizationSchema() {
    return {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "VitalsReview",
      "url": window.location.origin
    };
  },
  generateProductAndReviewSchema(r) {
    return {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Product",
          "name": r.nome,
          "image": r.imagem,
          "description": r.descricao
        },
        {
          "@type": "Review",
          "headline": `Análise de ${r.nome}`,
          "reviewRating": { "@type": "Rating", "ratingValue": r.nota, "bestRating": "5" },
          "author": { "@type": "Organization", "name": "VitalsReview" }
        }
      ]
    };
  },
  generateArticleSchema(post) {
    return {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": post.title,
      "description": post.metaDescription,
      "image": post.image
    };
  }
};
