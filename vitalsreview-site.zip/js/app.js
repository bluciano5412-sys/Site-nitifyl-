import { Router } from './router.js';
import { reviewsData } from './data/reviews.js';
import { blogPosts } from './data/blog.js';
import { Utils } from './utils.js';

function setupGlobalSearch() {
  const input = document.getElementById('global-search');
  const dropdown = document.getElementById('search-results-dropdown');
  if (!input || !dropdown) return;

  const allItems = [
    ...Object.values(reviewsData).map(r => ({ type: 'Review', title: r.nome, url: `/reviews/${r.slug}` })),
    ...blogPosts.map(p => ({ type: 'Blog', title: p.title, url: `/blog/${p.slug}` }))
  ];

  function renderResults(query) {
    const q = query.trim().toLowerCase();
    if (!q) {
      dropdown.classList.add('hidden');
      dropdown.innerHTML = '';
      return;
    }
    const matches = allItems.filter(item => item.title.toLowerCase().includes(q)).slice(0, 6);
    if (matches.length === 0) {
      dropdown.innerHTML = `<div class="p-3 text-sm text-slate-400">Nenhum resultado encontrado.</div>`;
    } else {
      dropdown.innerHTML = matches.map(m => `
        <a href="${m.url}" data-link class="block px-3 py-2 text-sm hover:bg-slate-50 border-b last:border-0 border-slate-100">
          <span class="text-[10px] uppercase font-bold text-emerald-600 block">${m.type}</span>
          ${Utils.escapeHTML(m.title)}
        </a>
      `).join('');
    }
    dropdown.classList.remove('hidden');
  }

  input.addEventListener('input', (e) => renderResults(e.target.value));
  input.addEventListener('focus', (e) => { if (e.target.value) renderResults(e.target.value); });

  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target) && e.target !== input) {
      dropdown.classList.add('hidden');
    }
  });

  dropdown.addEventListener('click', (e) => {
    const link = e.target.closest('[data-link]');
    if (link) {
      e.preventDefault();
      dropdown.classList.add('hidden');
      input.value = '';
      Router.navigate(link.getAttribute('href'));
    }
  });
}

function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(() => {
        // Falha silenciosa: o site funciona normalmente sem o service worker.
      });
    });
  }
}

function boot() {
  Router.syncRoute();
  setupGlobalSearch();
  registerServiceWorker();

  window.addEventListener('popstate', () => Router.syncRoute());
}

document.addEventListener('DOMContentLoaded', boot);
