import { reviewsData } from './data/reviews.js';
import { blogPosts } from './data/blog.js';
import { Utils } from './utils.js';

export const UIEngine = {
  renderAdSlot(slotId = "default-slot") {
    return `
      <div class="my-6 bg-slate-100 border border-slate-200 rounded-xl p-3 text-center">
          <span class="text-[10px] uppercase tracking-wider text-slate-400 block mb-1">Publicidade</span>
          <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-XXXXXXXX" data-ad-slot="${slotId}" data-ad-format="auto"></ins>
      </div>
    `;
  },
  renderBreadcrumb(links) {
    return `
      <nav class="max-w-7xl mx-auto px-4 pt-4 text-xs font-semibold text-slate-400 flex items-center gap-2">
        <a href="/" data-link class="hover:text-emerald-600">Home</a>
        ${links.map(l => `<span>/</span><a href="${l.url}" data-link class="hover:text-emerald-600 last:text-slate-500 last:pointer-events-none">${Utils.escapeHTML(l.name)}</a>`).join('')}
      </nav>
    `;
  },
  renderHome() {
    const sliceReviews = Object.keys(reviewsData).slice(0, 3).map(k => reviewsData[k]);
    return `
      <section class="bg-slate-900 text-white py-20 px-4 text-center">
          <h1 class="text-4xl sm:text-5xl font-black mb-4">Guia Independente de Suplementos</h1>
          <p class="text-slate-300 mb-8 max-w-xl mx-auto">Análises claras e diretas para te ajudar a decidir com mais informação — sem promessas milagrosas.</p>
          <div class="flex justify-center gap-4">
              <a href="/reviews" data-link class="bg-emerald-500 px-6 py-3 rounded-xl font-bold">Ver Reviews</a>
              <a href="/blog" data-link class="bg-slate-800 px-6 py-3 rounded-xl font-bold">Ver Blog</a>
          </div>
      </section>
      <section class="max-w-7xl mx-auto px-4 py-16">
          <h2 class="text-2xl font-black mb-6">Análises em destaque</h2>
          <div class="grid md:grid-cols-3 gap-8">${sliceReviews.map(r => this.generateReviewCard(r)).join('')}</div>
      </section>
      ${this.renderAdSlot('home-slot')}
    `;
  },
  renderReviewsCatalog() {
    return `
      ${this.renderBreadcrumb([{ name: "Reviews", url: "/reviews" }])}
      <div class="max-w-7xl mx-auto px-4 py-12">
          <h1 class="text-3xl font-black mb-8">Reviews de Suplementos</h1>
          <div class="grid md:grid-cols-3 gap-8">${Object.keys(reviewsData).map(k => this.generateReviewCard(reviewsData[k])).join('')}</div>
      </div>
    `;
  },
  renderReviewDetail(r) {
    return `
      ${this.renderBreadcrumb([{ name: "Reviews", url: "/reviews" }, { name: r.nome, url: `/reviews/${r.slug}` }])}
      <div class="max-w-3xl mx-auto px-4 py-12">
          <div class="bg-amber-50 border border-amber-200 text-amber-900 text-xs rounded-lg p-3 mb-6">
              Este conteúdo é informativo e contém links de afiliado. Não é laudo laboratorial nem recomendação médica.
          </div>
          <div class="flex items-center gap-3 mb-2">
            <h1 class="text-3xl font-black">${Utils.escapeHTML(r.nome)}</h1>
            <span class="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-1 rounded-full">Nota ${r.nota}/5</span>
          </div>
          <p class="text-slate-500 mb-6">Análise independente da equipe VitalsReview</p>
          <img src="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 9'></svg>" data-src="${r.imagem}" alt="${Utils.escapeHTML(r.nome)}" class="w-full h-64 object-cover rounded-xl mb-6 bg-slate-200">
          <p class="text-slate-700 mb-2 font-semibold">${Utils.escapeHTML(r.resumo)}</p>
          <p class="text-slate-700 mb-6">${Utils.escapeHTML(r.descricao)}</p>
          <div class="grid md:grid-cols-2 gap-6 my-6">
              <div class="bg-emerald-50 p-4 rounded-xl"><h4 class="font-bold text-emerald-900 mb-2">Prós</h4><ul class="text-sm space-y-1">${r.pros.map(p => `<li>• ${Utils.escapeHTML(p)}</li>`).join('')}</ul></div>
              <div class="bg-rose-50 p-4 rounded-xl"><h4 class="font-bold text-rose-900 mb-2">Contras</h4><ul class="text-sm space-y-1">${r.cons.map(c => `<li>• ${Utils.escapeHTML(c)}</li>`).join('')}</ul></div>
          </div>
          <div class="bg-slate-50 border border-slate-200 p-6 rounded-xl text-center my-8">
              <p class="text-xs text-slate-500 mb-3">Link de afiliado — podemos receber comissão sem custo extra para você.</p>
              <a href="${r.affiliate}" target="_blank" rel="noopener noreferrer sponsored" class="inline-block bg-amber-500 text-white font-bold px-6 py-3 rounded-xl">Ver site oficial do fabricante</a>
          </div>
      </div>
    `;
  },
  renderBlogCatalog() {
    return `
      ${this.renderBreadcrumb([{ name: "Blog", url: "/blog" }])}
      <div class="max-w-7xl mx-auto px-4 py-12">
          <h1 class="text-3xl font-black mb-8">Blog</h1>
          <div class="grid md:grid-cols-3 gap-8" id="blog-posts-grid">${blogPosts.map(p => this.generateBlogCard(p)).join('')}</div>
      </div>
    `;
  },
  renderBlogDetail(post) {
    return `
      ${this.renderBreadcrumb([{ name: "Blog", url: "/blog" }, { name: post.title, url: `/blog/${post.slug}` }])}
      <div class="max-w-2xl mx-auto px-4 py-12">
          <h1 class="text-3xl font-black mb-4">${Utils.escapeHTML(post.title)}</h1>
          <img src="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 9'></svg>" data-src="${post.image}" alt="${Utils.escapeHTML(post.title)}" class="w-full h-64 object-cover rounded-xl mb-6 bg-slate-200">
          <div class="prose prose-slate max-w-none text-slate-700 leading-relaxed">${post.content}</div>
      </div>
    `;
  },
  renderAbout() {
    return `
      <div class="max-w-2xl mx-auto px-4 py-16">
        <h1 class="text-3xl font-black mb-4">Quem Somos</h1>
        <p class="text-slate-600 mb-4">O VitalsReview é um portal independente que analisa suplementos com base em composição, dosagem, estudos públicos disponíveis e relatos de usuários.</p>
        <p class="text-slate-600">Somos remunerados por comissões de afiliado quando você compra através dos nossos links — isso não altera o preço que você paga, mas é justo que você saiba disso antes de continuar navegando.</p>
      </div>
    `;
  },
  renderContact() {
    return `
      <div class="max-w-md mx-auto px-4 py-16">
          <h1 class="text-3xl font-black mb-6 text-center">Contato</h1>
          <form id="contact-form" class="space-y-4 bg-white p-6 rounded-xl border border-slate-200">
              <div><label class="block text-sm font-bold mb-1">Email</label><input type="email" id="newsEmail" required class="w-full p-2 border rounded-lg"></div>
              <button type="submit" class="w-full bg-emerald-600 text-white py-2.5 rounded-lg font-bold">Enviar</button>
          </form>
          <p id="contact-feedback" class="text-center text-sm mt-4 hidden"></p>
      </div>
    `;
  },
  renderLegalPage(title, text) {
    return `<div class="max-w-2xl mx-auto px-4 py-16"><h1 class="text-2xl font-black mb-4">${Utils.escapeHTML(title)}</h1><p class="text-slate-600 leading-relaxed">${text}</p></div>`;
  },
  generateReviewCard(r) {
    return `
      <div class="bg-white border rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between h-full">
          <div>
              <img src="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 9'></svg>" data-src="${r.imagem}" alt="${Utils.escapeHTML(r.nome)}" class="w-full h-48 object-cover bg-slate-100">
              <div class="p-5">
                  <div class="flex items-center justify-between mb-1">
                    <h3 class="font-bold text-lg">${Utils.escapeHTML(r.nome)}</h3>
                    <span class="text-xs font-bold text-emerald-700">${r.nota}/5</span>
                  </div>
                  <p class="text-sm text-slate-600 line-clamp-2">${Utils.escapeHTML(r.descricao)}</p>
              </div>
          </div>
          <div class="p-5 pt-0 space-y-2">
              <a href="/reviews/${r.slug}" data-link class="block text-center bg-slate-100 py-2 text-sm rounded-lg font-bold">Ler Análise</a>
              <a href="${r.affiliate}" target="_blank" rel="noopener noreferrer sponsored" class="block text-center bg-emerald-600 text-white py-2 text-sm rounded-lg font-bold">Site Oficial</a>
          </div>
      </div>
    `;
  },
  generateBlogCard(p) {
    return `
      <div class="bg-white border rounded-2xl p-5 shadow-sm flex flex-col justify-between h-full">
          <div>
              <h3 class="font-bold text-base mb-2 line-clamp-2">${Utils.escapeHTML(p.title)}</h3>
              <p class="text-sm text-slate-600 line-clamp-2">${Utils.escapeHTML(p.metaDescription)}</p>
          </div>
          <a href="/blog/${p.slug}" data-link class="text-emerald-600 font-bold text-sm mt-4 inline-block">Ler Mais &rarr;</a>
      </div>
    `;
  }
};
