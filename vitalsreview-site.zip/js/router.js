import { UIEngine } from './ui.js';
import { SEOManager } from './seo.js';
import { reviewsData } from './data/reviews.js';
import { blogPosts } from './data/blog.js';
import { Utils } from './utils.js';

export const Router = {
  syncRoute() {
    const path = window.location.pathname;
    const viewContainer = document.getElementById('app-view');
    if (!viewContainer) return;

    SEOManager.clearSchema();

    if (path.startsWith('/reviews/')) {
      const slug = path.replace('/reviews/', '');
      const review = Object.values(reviewsData).find(r => r.slug === slug);
      if (review) {
        viewContainer.innerHTML = UIEngine.renderReviewDetail(review);
        SEOManager.updateTags(`Review ${review.nome}`, review.descricao, null, review.imagem);
        SEOManager.injectSchema(SEOManager.generateProductAndReviewSchema(review));
      } else { this.render404(viewContainer); }
      this.postRender();
      return;
    }

    if (path.startsWith('/blog/')) {
      const slug = path.replace('/blog/', '');
      const post = blogPosts.find(p => p.slug === slug);
      if (post) {
        viewContainer.innerHTML = UIEngine.renderBlogDetail(post);
        SEOManager.updateTags(post.title, post.metaDescription, null, post.image);
        SEOManager.injectSchema(SEOManager.generateArticleSchema(post));
      } else { this.render404(viewContainer); }
      this.postRender();
      return;
    }

    if (path.startsWith('/legal/')) {
      const type = path.replace('/legal/', '');
      const titles = { privacy: "Política de Privacidade", terms: "Termos de Uso", affiliate: "Divulgação de Afiliados", medical: "Aviso Médico Legal" };
      const texts = {
        privacy: "Coletamos apenas os dados necessários para responder contatos e melhorar o site, como e-mail informado voluntariamente no formulário de contato. Não vendemos seus dados a terceiros.",
        terms: "O conteúdo deste site tem finalidade informativa e educacional. O uso das informações aqui presentes é de responsabilidade do usuário.",
        affiliate: "Este site participa do programa de afiliados da ClickBank. Isso significa que podemos receber uma comissão quando você compra um produto através de um dos nossos links, sem qualquer custo adicional para você.",
        medical: "As informações deste site não substituem consulta, diagnóstico ou tratamento médico ou nutricional profissional. Consulte sempre um profissional de saúde antes de iniciar o uso de qualquer suplemento."
      };
      if (titles[type]) {
        viewContainer.innerHTML = UIEngine.renderLegalPage(titles[type], texts[type]);
        SEOManager.updateTags(titles[type], texts[type]);
      } else { this.render404(viewContainer); }
      this.postRender();
      return;
    }

    switch (path) {
      case '/':
        viewContainer.innerHTML = UIEngine.renderHome();
        SEOManager.updateTags("Home", "Guia independente de suplementos com análises, prós e contras baseados em composição e estudos públicos.");
        SEOManager.injectSchema(SEOManager.generateOrganizationSchema());
        break;
      case '/reviews':
        viewContainer.innerHTML = UIEngine.renderReviewsCatalog();
        SEOManager.updateTags("Reviews", "Catálogo de análises independentes de suplementos populares.");
        break;
      case '/blog':
        viewContainer.innerHTML = UIEngine.renderBlogCatalog();
        SEOManager.updateTags("Blog", "Artigos sobre suplementação, nutrição e saúde baseados em fontes confiáveis.");
        break;
      case '/about':
        viewContainer.innerHTML = UIEngine.renderAbout();
        SEOManager.updateTags("Quem Somos", "Conheça o VitalsReview e como funciona nosso modelo de afiliados.");
        break;
      case '/contact':
        viewContainer.innerHTML = UIEngine.renderContact();
        SEOManager.updateTags("Contato", "Fale com a equipe VitalsReview.");
        this.bindContactEvents();
        break;
      default:
        this.render404(viewContainer);
        break;
    }
    this.postRender();
  },
  navigate(url) {
    window.history.pushState(null, null, url);
    this.syncRoute();
    window.scrollTo(0, 0);
  },
  postRender() {
    Utils.lazyLoadImages();
    document.querySelectorAll('[data-link]').forEach(el => {
      el.removeAttribute('data-link');
      el.addEventListener('click', e => {
        e.preventDefault();
        this.navigate(el.getAttribute('href'));
      });
    });
  },
  render404(c) {
    c.innerHTML = `
      <div class="text-center py-24 px-4">
        <h1 class="text-3xl font-bold mb-4">404 - Página não encontrada</h1>
        <p class="text-slate-500 mb-6">O endereço que você tentou acessar não existe.</p>
        <a href="/" data-link class="inline-block bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold">Voltar para a Home</a>
      </div>
    `;
  },
  bindContactEvents() {
    const form = document.getElementById('contact-form');
    const feedback = document.getElementById('contact-feedback');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('newsEmail');
      const email = emailInput.value.trim();

      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        feedback.textContent = 'Digite um e-mail válido.';
        feedback.className = 'text-center text-sm mt-4 text-rose-600 font-semibold';
        feedback.classList.remove('hidden');
        return;
      }

      // Aqui entraria a chamada real para seu backend/serviço de e-mail
      // (Netlify Forms, Formspree, EmailJS, etc). Por enquanto, só confirma visualmente.
      feedback.textContent = 'Mensagem enviada! Em breve entraremos em contato.';
      feedback.className = 'text-center text-sm mt-4 text-emerald-700 font-semibold';
      feedback.classList.remove('hidden');
      form.reset();
    });
  }
};
